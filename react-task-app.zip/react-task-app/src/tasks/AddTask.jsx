import React, { useState } from "react";
import { addTask } from "../service/api";
import Navbar from "../components/Navbar";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const AddTask = () => {
  const [task, setTask] = useState({
    taskName: "",
    duration: "",
    isCompleted: false,
    assignedTo: ""
  });

  const [message, setMessage] = useState("");

  //  Handle input changes
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setTask({
      ...task,
      [name]: type === "checkbox" ? checked : value
    });
  };

  // Form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Convert duration to integer
      const requestData = {
        ...task,
        duration: parseInt(task.duration, 10)  // Ensure duration is an integer
      };

      await addTask(requestData);
      setMessage("Task added successfully!");
      
      // Reset form
      setTask({
        taskName: "",
        duration: "",
        isCompleted: false,
        assignedTo: ""
      });
      toast.success(
               "✅ Task added successfully!"
            );
    } catch (error) {
      console.error("Error adding task:", error);
      setMessage("Failed to add task. Please try again.");
    }
  };

  return (
    <div className="addTask">
      <ToastContainer position="top-right" autoClose={2000} />
      <Navbar />
      <h2>Add New Task</h2>

      {message && (
        <p style={{ color: message.includes("success") ? "green" : "red" }}>
          {message}
        </p>
      )}

      <form className="taskForm" onSubmit={handleSubmit}>
        
        {/* Task Name */}
        <label>Task Name:</label>
        <input
          type="text"
          name="taskName"
          value={task.taskName}
          onChange={handleChange}
          required
          placeholder="Enter task name"
        />

        {/* Duration */}
        <label>Duration:</label>
        <input
          type="number"
          name="duration"
          value={task.duration}
          onChange={handleChange}
          required
          min="1"
          placeholder="Enter duration in days"
        />        

        {/* Assigned To */}
        <label>Assigned To:</label>
        <input
          type="text"
          name="assignedTo"
          value={task.assignedTo}
          onChange={handleChange}
          required
          placeholder="Enter username"
        />

        {/* Submit Button */}
        <button type="submit" style={{ marginTop: "15px", cursor: "pointer" }}>
          Add Task
        </button>
      </form>
    </div>
  );
};

export default AddTask;
