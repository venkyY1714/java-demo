function Header({ taskLogo,title }) {
  return (
    <header>
        <img src={taskLogo} alt="Task Logo" style={{ width: '50px', height: '50px' }} />
        <h1>Task Management Application</h1>
      </header>
  );
}

export default Header;
