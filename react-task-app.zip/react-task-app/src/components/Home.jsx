import Navbar from "./Navbar";

function Home({ task_manager }) {

    return (
        <div>
            <Navbar />
            <h3>Welcome to Task Management App</h3>

            <img src={task_manager} alt="Task Logo" style={{ width: '400px', height: '300px' }} />
        </div>
    );
}

export default Home;