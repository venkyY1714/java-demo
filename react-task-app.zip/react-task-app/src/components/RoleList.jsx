import { useEffect, useState } from "react";
import { getAllRoles } from "../service/api";
import Navbar from "./Navbar";

const RoleList = () => {
  const [roles, setRoles] = useState([]);

  useEffect(() => {
    const fetchRoles = async () => {
      try {
        const data = await getAllRoles();
        console.log(data);
        setRoles(data);
      } catch (error) {
        console.error("Failed to fetch roles:", error);
      }
    };

    fetchRoles();
  }, []);

  return (
    <div>
      <Navbar />
      <h2>All Roles</h2>
      <div className="roleList">
        <table className="styled-table">
          <thead>
            <tr>
              <th>
                <h2>ID</h2>
              </th>
              <th>
                <h2>ROLE</h2>
              </th>
            </tr>
          </thead>
          <tbody>
            {roles.map((role) => (
              <tr key={role.id}>
                <td>
                  {role.id}
                </td>
                <td>
                  {role.roleName}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RoleList;
