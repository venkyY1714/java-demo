import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Task from "./tasks/Task";
import TaskList from "./tasks/TaskList";
import UpdateTask from "./tasks/UpdateTask";
import AddTask from "./tasks/AddTask";
import ProtectedRoute from "./components/ProtectedRoute";
import Dashboard from "./components/Dashboard";
import RoleList from "./components/RoleList";
import AddRole from "./components/AddRole";
import AssignRole from "./components/AssignRole";
import { RoleProvider } from "./context/RoleProvider";
import AuthForm from "./auth/AuthForm";
import taskLogo from './assets/task-logo.gif'; // adjust the path if needed
import Home from "./components/Home";
import task_manager from './assets/task_manager.jpg';

function App() {
  return (
    <div className="App">
      <Router>
        <RoleProvider>
          <Header taskLogo={taskLogo} title="Task Management App" />
          <Routes>
            <Route path="/" element={<AuthForm />} />
            <Route path="/home" element={<Home task_manager={task_manager} />} />
            {/* <Route path="/register" element={<Register />} /> */}
            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/roles" element={<ProtectedRoute><RoleList /></ProtectedRoute>} />
            <Route path="/add-role" element={<ProtectedRoute><AddRole /></ProtectedRoute>} />
            <Route path="/assign-role" element={<ProtectedRoute><AssignRole /></ProtectedRoute>} />
            <Route path="/tasks" element={<ProtectedRoute><TaskList /></ProtectedRoute>} />
            <Route path="/task/:id" element={<ProtectedRoute><Task /></ProtectedRoute>} />
            <Route path="/create-task" element={<ProtectedRoute><AddTask /></ProtectedRoute>} />
            <Route path="/update-task/:id" element={<ProtectedRoute><UpdateTask /></ProtectedRoute>} />
          </Routes>
        </RoleProvider>
      </Router>
    </div>
  );
}

export default App;
