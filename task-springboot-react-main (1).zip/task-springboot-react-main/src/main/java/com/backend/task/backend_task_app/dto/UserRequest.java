package com.backend.task.backend_task_app.dto;

import lombok.Data;

@Data
public class UserRequest {

	String username;
	String password;
}
