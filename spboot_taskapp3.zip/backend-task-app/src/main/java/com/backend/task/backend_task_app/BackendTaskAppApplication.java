package com.backend.task.backend_task_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTaskAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendTaskAppApplication.class, args);
	}

}
